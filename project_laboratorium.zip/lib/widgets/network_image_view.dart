import 'package:flutter/material.dart';

class NetworkImageView extends StatelessWidget {
  final String imageUrl;
  final double? width;
  final double? height;
  final BoxFit fit;
  final BorderRadius? radius;

  const NetworkImageView({
    super.key,
    required this.imageUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.radius,
  });

  @override
  Widget build(BuildContext context) {
    final url = imageUrl.trim();

    bool isHttpUrl = url.startsWith('http://') || url.startsWith('https://');

    Widget image;

    if (!isHttpUrl || url.isEmpty) {
      image = _fallback();
    } else {
      image = Image.network(
        url,
        width: width,
        height: height,
        fit: fit,
        headers: const {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        },
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;

          return Container(
            width: width,
            height: height,
            color: const Color(0xFF1E1E1E),
            alignment: Alignment.center,
            child: const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.orange,
              ),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          return _fallback();
        },
      );
    }

    if (radius != null) {
      return ClipRRect(
        borderRadius: radius!,
        child: image,
      );
    }

    return image;
  }

  Widget _fallback() {
    return Container(
      width: width,
      height: height,
      color: const Color(0xFF2A2A2A),
      alignment: Alignment.center,
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.broken_image_outlined,
            size: 32,
            color: Colors.grey,
          ),
          SizedBox(height: 4),
          Text(
            "URL Tidak Valid / Gagal",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}