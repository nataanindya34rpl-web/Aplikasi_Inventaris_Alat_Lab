import 'package:flutter/material.dart';

import '../../widgets/bottom_nav.dart';
import '../../services/firestore_service.dart';

import '../home_dashboard.dart';
import 'inventory_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    HomeDashboard(),
    InventoryScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    initializeDummyData();
  }

  Future<void> initializeDummyData() async {
    try {
      await FirestoreService().seedDummyItemsIfEmpty();
    } catch (e) {
      debugPrint('Gagal membuat data dummy: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: selectedIndex,
        children: pages,
      ),

      bottomNavigationBar: BottomNav(
        selectedIndex: selectedIndex,
        onChanged: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
      ),
    );
  }
}