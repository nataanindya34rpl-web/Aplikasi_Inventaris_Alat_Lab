import 'package:flutter/material.dart';

import '../../config/app_theme.dart';
import '../../models/item_model.dart';
import '../../services/firestore_service.dart';

class ItemFormScreen extends StatefulWidget {
  final ItemModel? item;

  const ItemFormScreen({
    super.key,
    this.item,
  });

  @override
  State<ItemFormScreen> createState() => _ItemFormScreenState();
}

class _ItemFormScreenState extends State<ItemFormScreen> {
  final formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final categoryController = TextEditingController();
  final codeController = TextEditingController();
  final imageController = TextEditingController();
  final specificationController = TextEditingController();

  String status = 'Available';
  bool loading = false;

  bool get isEditing => widget.item != null;

  @override
  void initState() {
    super.initState();

    final item = widget.item;

    if (item != null) {
      nameController.text = item.itemName;
      categoryController.text = item.category;
      codeController.text = item.code;
      imageController.text = item.image;
      specificationController.text = item.specification;
      status = item.status;
    }
  }

  Future<void> saveItem() async {
    if (!formKey.currentState!.validate()) return;

    final imageUrl = imageController.text.trim();

    if (imageUrl.isNotEmpty) {
      final uri = Uri.tryParse(imageUrl);

      if (uri == null ||
          (uri.scheme != 'http' && uri.scheme != 'https') ||
          uri.host.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('URL gambar tidak valid.'),
          ),
        );
        return;
      }
    }

    setState(() => loading = true);

    try {
      final item = ItemModel(
        itemId: widget.item?.itemId ?? '',
        itemName: nameController.text.trim(),
        category: categoryController.text.trim(),
        code: codeController.text.trim(),
        status: status,
        image: imageUrl,
        specification: specificationController.text.trim(),
        createdAt:
            widget.item?.createdAt ?? DateTime.now(),
      );

      if (isEditing) {
        await FirestoreService().updateItem(item);
      } else {
        await FirestoreService().addItem(item);
      }

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isEditing
                ? 'Inventaris berhasil diperbarui.'
                : 'Inventaris berhasil ditambahkan.',
          ),
        ),
      );

      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Terjadi kesalahan: $e'),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  Widget buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    int maxLines = 1,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        keyboardType: keyboardType,
        validator: validator ??
            (value) {
              if (value == null || value.trim().isEmpty) {
                return '$label wajib diisi.';
              }
              return null;
            },
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          alignLabelWithHint: maxLines > 1,
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    categoryController.dispose();
    codeController.dispose();
    imageController.dispose();
    specificationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          isEditing ? 'Edit Inventaris' : 'Tambah Inventaris',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE0F2F1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.inventory_2_outlined,
                    size: 45,
                    color: AppTheme.secondary,
                  ),
                ),
              ),

              const SizedBox(height: 25),

              buildInput(
                label: 'Nama Barang',
                controller: nameController,
                icon: Icons.inventory,
              ),

              buildInput(
                label: 'Kategori',
                controller: categoryController,
                icon: Icons.category_outlined,
              ),

              buildInput(
                label: 'Kode Serial',
                controller: codeController,
                icon: Icons.qr_code,
              ),

              buildInput(
                label: 'URL Gambar',
                controller: imageController,
                icon: Icons.image_outlined,
                validator: (value) {
                  final text = value?.trim() ?? '';

                  if (text.isEmpty) return null;

                  final uri = Uri.tryParse(text);

                  if (uri == null ||
                      (uri.scheme != 'http' &&
                          uri.scheme != 'https') ||
                      uri.host.isEmpty) {
                    return 'Masukkan URL gambar yang valid.';
                  }

                  return null;
                },
                keyboardType: TextInputType.url,
              ),

              buildInput(
                label: 'Spesifikasi Barang',
                controller: specificationController,
                icon: Icons.description_outlined,
                maxLines: 4,
              ),

              const SizedBox(height: 5),

              const Text(
                'Status Barang',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              DropdownButtonFormField<String>(
                initialValue: status,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.info_outline),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'Available',
                    child: Text('Available'),
                  ),
                  DropdownMenuItem(
                    value: 'Borrowed',
                    child: Text('Borrowed'),
                  ),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => status = value);
                  }
                },
              ),

              const SizedBox(height: 28),

              ElevatedButton(
                onPressed: loading ? null : saveItem,
                child: loading
                    ? const CircularProgressIndicator(
                        color: Colors.white,
                      )
                    : Text(
                        isEditing
                            ? 'Simpan Perubahan'
                            : 'Tambah Inventaris',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}